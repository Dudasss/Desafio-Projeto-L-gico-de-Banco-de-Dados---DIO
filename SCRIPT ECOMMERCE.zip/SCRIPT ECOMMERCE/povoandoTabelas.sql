-- queries utilizando o bd de ecommerce

use ecommerce;

-- povoando a tabela de clientes
INSERT INTO clients (`Fname`,`Minit`,`Lname`,`CPF`,`Address`)
VALUES
  ("Autumn","N","Camacho","35238874864","119704 Massa Road"),
  ("Ryder","M","Conner","7217184322","3140 Integer Avenue"),
  ("Ina","I","Sexton","05765560667","3911368 Commodo Rd."),
  ("Jin","L","Davidson","33147366742","4754235 Facilisis Av."),
  ("Hilel","Z","Brady","69596294185","7479 Duis Rd."),
  ("Cain","P","Franks","59269380313","8097916 Vulputate, St."),
  ("Kane","K","Knapp","36054596727","4158859 Nibh Street"),
  ("Craig","B","Baxter","91890765145","6037916 Sit Rd."),
  ("Patience","K","Torres","85465375118","Ap #574 Mus. Ave"),
  ("Melvin","A","Chen","35432556564","1739623 Tempor Street");
INSERT INTO clients (`Fname`,`Minit`,`Lname`,`CPF`,`Address`)
VALUES
  ("Kiara","J","Santiago","89196122339","#9868519 Adipiscing Avenue"),
  ("Cassandra","J","Conley","48938229262","4055447 Vitae, Rd."),
  ("Doris","M","Burke","06125423655","1697384 Leo. Avenue"),
  ("Rafael","H","Armstrong","64734213448","7258991 Sed Rd."),
  ("Jamal","C","Buchanan","18602570467","7274 Aliquam Ave"),
  ("Zelenia","S","Franco","36095424313","#813-7610 Magna. St."),
  ("Eaton","P","Copeland","20827249962","#134-6007 Netus Avenue"),
  ("Dorian","C","Alford","17053169263","8157826 Nisi Rd."),
  ("Tanek","I","Maxwell","73217243820","7151 Enim, Rd."),
  ("Irene","B","Curtis","9880678862","#271-2326 Eu St.");
  
  select * from clients;
  
  -- povoando tabela de pedidos
  
  INSERT INTO orders (`IdOrderClient`,`orderStatus`,`orderDescription`,`sendValue`,`paymentCash`)
VALUES
  (18,"Em Processamento","dui, nec tempus",82.9,"1"),
  (22,"Cancelado","cursus no egestas",43.9,"0"),
  (19,"Cancelado","eros turpis non",88.9,"0"),
  (22,"Em Processamento","nulla at sem",10.9,"0"),
  (18,"Confirmado","interm feugiaSed",56.9,"1"),
  (21,"Em Processamento","Duis gravida Praesent",65.9,"1"),
  (20,"Cancelado","leo Vivamus nibh",91.9,"0"),
  (25,"Confirmado","risus quis diam",91.9,"1"),
  (19,"Confirmado","ligula Donec luctus",14.9,"0"),
  (18,"Em Processamento","sed orci lortis",95.9,"1");

INSERT INTO orders (`IdOrderClient`,`orderStatus`,`orderDescription`,`sendValue`,`paymentCash`)
VALUES
  (11,"Em Processamento","arcu. Curabitur ut",49,"0"),
  (12,"Em Processamento","Cras pellentesque. Sed",7,"0"),
  (23,"Confirmado","consectetuer rhoncus. Nullam",44,"0"),
  (25,"Cancelado","non, egestas a,",31,"0"),
  (18,"Cancelado","Quisque varius. Nam",24,"1"),
  (15,"Confirmado","eu nulla at",75,"0"),
  (20,"Em Processamento","Cras eu tellus",99,"1"),
  (27,"Confirmado","semper auctor. Mauris",66,"1"),
  (27,"Cancelado","in, hendrerit consectetuer,",61,"1"),
  (20,"Confirmado","in faucibus orci",80,"1");
INSERT INTO orders (`IdOrderClient`,`orderStatus`,`orderDescription`,`sendValue`,`paymentCash`)
VALUES
  (14,"Em Processamento","lorem vitae odio",89,"1"),
  (29,"Confirmado","Vivamus molestie dapibus",7,"0"),
  (21,"Em Processamento","Nam consequat dolor",42,"1"),
  (19,"Em Processamento","lobortis, nisi nibh",66,"0"),
  (30,"Confirmado","Lorem ipsum dolor",16,"0"),
  (24,"Cancelado","sollicitudin a, malesuada",30,"1"),
  (25,"Cancelado","enim commodo hendrerit.",69,"1"),
  (29,"Confirmado","ornare egestas ligula.",89,"1"),
  (21,"Em Processamento","dis parturient montes,",35,"1"),
  (22,"Confirmado","Cum sociis natoque",48,"0");
INSERT INTO orders (`IdOrderClient`,`orderStatus`,`orderDescription`,`sendValue`,`paymentCash`)
VALUES
  (26,"Em Processamento","nec metus facilisis",47,"0"),
  (12,"Em Processamento","tincidunt congue turpis.",81,"1"),
  (28,"Confirmado","non enim commodo",25,"1"),
  (18,"Em Processamento","orci luctus et",85,"1"),
  (20,"Confirmado","ut ipsum ac",80,"1"),
  (18,"Cancelado","velit eu sem.",15,"1"),
  (19,"Confirmado","lacinia orci, consectetuer",76,"1"),
  (27,"Confirmado","et, eros. Proin",12,"0"),
  (11,"Cancelado","dui. Fusce aliquam,",79,"0"),
  (15,"Confirmado","ornare egestas ligula.",70,"0");
  
  -- populando produtos
  INSERT INTO product (`Pname`,`classification_kids`,`categorie`,`avaliacao`,`size`)
VALUES
  ("noodles","1","Alimentos",2,"medium"),
  ("pasta","1","Vestimenta",3,"medium"),
  ("noodles","0","Móveis",10,"medium"),
  ("pies","1","Eletrônico",1,"medium"),
  ("pies","1","Móveis",6,"large"),
  ("noodles","1","Móveis",7,"small"),
  ("sandwiches","1","Vestimenta",4,"medium"),
  ("pasta","0","Vestimenta",5,"small"),
  ("noodles","0","Vestimenta",5,"large"),
  ("soups","0","Móveis",0,"large");
INSERT INTO product (`Pname`,`classification_kids`,`categorie`,`avaliacao`,`size`)
VALUES
  ("salads","1","Brinquedos",10,"medium"),
  ("seafood","0","Brinquedos",9,"large"),
  ("stews","0","Móveis",1,"large"),
  ("cereals","0","Eletrônico",7,"small"),
  ("salads","1","Alimentos",6,"small"),
  ("seafood","0","Móveis",2,"medium"),
  ("seafood","1","Eletrônico",4,"large"),
  ("sandwiches","0","Vestimenta",0,"medium"),
  ("noodles","0","Brinquedos",2,"large"),
  ("stews","0","Vestimenta",9,"large");
INSERT INTO product (`Pname`,`classification_kids`,`categorie`,`avaliacao`,`size`)
VALUES
  ("noodles","1","Brinquedos",8,"large"),
  ("seafood","1","Eletrônico",10,"small"),
  ("sandwiches","1","Vestimenta",2,"small"),
  ("pies","0","Vestimenta",8,"large"),
  ("desserts","0","Eletrônico",2,"large"),
  ("pies","0","Vestimenta",9,"large"),
  ("desserts","0","Eletrônico",8,"small"),
  ("cereals","1","Brinquedos",10,"medium"),
  ("pasta","0","Eletrônico",4,"medium"),
  ("sandwiches","0","Vestimenta",3,"medium");
INSERT INTO product (`Pname`,`classification_kids`,`categorie`,`avaliacao`,`size`)
VALUES
  ("salads","1","Vestimenta",3,"large"),
  ("sandwiches","0","Vestimenta",0,"large"),
  ("noodles","0","Móveis",4,"large"),
  ("pasta","0","Eletrônico",2,"large"),
  ("soups","0","Brinquedos",3,"small"),
  ("stews","1","Alimentos",5,"large"),
  ("sandwiches","1","Alimentos",4,"large"),
  ("stews","0","Eletrônico",5,"small"),
  ("noodles","0","Brinquedos",5,"small"),
  ("pasta","1","Brinquedos",8,"small");
  
  -- populando product order
  INSERT INTO productorder (`idPOproduct`,`idPOorder`,`poQuantity`,`poStatus`)
VALUES
  (1,41,2,"Disponível");
  
  INSERT INTO productorder (`idPOproduct`,`idPOorder`,`poQuantity`,`poStatus`)
VALUES
  (12,91,60,"Sem Estoque"),
  (36,91,99,"Sem Estoque"),
  (38,91,36,"Disponível"),
  (20,94,75,"Disponível"),
  (29,92,58,"Sem Estoque"),
  (14,120,82,"Disponível"),
  (22,117,33,"Disponível"),
  (7,99,10,"Sem Estoque"),
  (14,98,46,"Disponível"),
  (18,98,63,"Sem Estoque");
INSERT INTO productorder (`idPOproduct`,`idPOorder`,`poQuantity`,`poStatus`)
VALUES
  (25,92,84,"Disponível"),
  (17,103,69,"Disponível"),
  (18,100,9,"Sem Estoque"),
  (12,90,11,"Sem Estoque"),
  (26,124,10,"Sem Estoque"),
  (30,124,16,"Disponível"),
  (5,110,31,"Disponível"),
  (4,106,25,"Disponível"),
  (36,106,99,"Disponível"),
  (37,110,20,"Disponível");
INSERT INTO productorder (`idPOproduct`,`idPOorder`,`poQuantity`,`poStatus`)
VALUES
  (12,122,44,"Sem Estoque"),
  (15,125,62,"Disponível"),
  (31,100,15,"Disponível"),
  (33,100,56,"Sem Estoque"),
  (30,96,86,"Sem Estoque"),
  (27,88,41,"Disponível"),
  (35,120,89,"Sem Estoque"),
  (10,90,28,"Disponível"),
  (27,97,22,"Disponível"),
  (34,108,19,"Disponível");
INSERT INTO productorder (`idPOproduct`,`idPOorder`,`poQuantity`,`poStatus`)
VALUES
  (7,112,40,"Sem Estoque"),
  (4,112,92,"Sem Estoque"),
  (11,108,15,"Disponível"),
  (26,106,11,"Disponível"),
  (6,90,89,"Disponível"),
  (37,115,83,"Sem Estoque"),
  (26,121,25,"Sem Estoque"),
  (32,106,98,"Disponível"),
  (12,88,53,"Disponível"),
  (8,103,94,"Disponível");
 
 -- povoando tabela seller
 
 INSERT INTO seller (`socialName`,`abstName`,`CNPJ`,`CPF`,`location`,`contact`)
VALUES
  ("Id Industries","Mae Felis Limited","6668631368","14217893403","China","1377685324"),
  ("Nullam Consulting","Lorem Foundation","13325163455","16941334135","South Africa","14774210808"),
  ("A Industries","Feug Consulting","3536788214","16387766307","Pakistan","19944890448"),
  ("Malesua Associates","Amet Associates","16127696221","11751187283","Ukraine","15821661177"),
  ("Orci In Institute","Fusce Fermentum Inc.","17915985173","13177415275","Canada","34236535"),
  ("Tellus Ltd","Aliquet Vel Inc.","5476747772","12516431725","Nigeria","11412238"),
  ("Nunc Incorporated","Eros Ultrices Corp.","138794370","5508042023","Canada","857183121"),
  ("Elementum At Egestas PC"," Senectus Inc.","1829717566","8775152928","Russian Federation","168258174"),
  ("Nam Consequat Consulting","Quis Pede Limited","7336560253","8959437375","Indonesia","426455611"),
  ("Ac Libero Nec Corp.","Mauris Vel LLC","5734968158","6014156288","Vietnam","81365887");
INSERT INTO seller (`socialName`,`abstName`,`CNPJ`,`CPF`,`location`,`contact`)
VALUES
  ("Semper Foundation","At LLC","15878074741","8309919622","Austria","435864465"),
  ("Nisl Quisque LLC","Non Inc.","3832527716","12375987582","United States","134243583"),
  ("Diam Nunc Associates","Lorem Sit Amet LLP","5627768398","8719235685","Nigeria","996643671"),
  ("Magna Sed Ltd","Sapien Cursus In Institute","12142704312","12268651896","Norway","1781152658"),
  ("Quisque Fringilla Institute","Cras Sed LLP","15248784618","9415342812","Russian Federation","458586153"),
  ("Facilisis Inc.","Velit Pellentesque Ultricies Industries","1568039913","5228465868","Singapore","14979297322"),
  ("A PC","Egestas Nunc Sed LLC","3316111825","12334937987","Brazil","4144510966"),
  ("Cursus Non Egestas Corporation","Vehicula Aliquet Institute","18391379816","7804950347","South Korea","309650806"),
  ("Neque Pellentesque LLC","Nostra Per Inceptos Corp.","13443128172","17415538561","New Zealand","11622788"),
  ("Elit PC","Adipiscing Ligula Corp.","12063851808","16138758665","Sweden","3482972449");
  
-- populando tabela de product seller
select * from seller;
INSERT INTO productSeller (`idPSeller`,`idProduct`,`prodQuantity`)
VALUES
  (2,36,22),
  (7,28,19),
  (10,25,87),
  (8,5,50),
  (8,19,58),
  (2,15,14),
  (7,18,84),
  (7,6,77),
  (22,1,82),
  (4,17,28);
INSERT INTO productSeller (`idPSeller`,`idProduct`,`prodQuantity`)
VALUES
  (28,13,35),
  (3,35,71),
  (1,25,74),
  (7,2,91),
  (23,5,40),
  (23,17,65),
  (21,20,97),
  (21,28,45),
  (5,37,89),
  (26,6,34);
  select * from seller;
INSERT INTO productSeller (`idPSeller`,`idProduct`,`prodQuantity`)
VALUES
  (8,4,50),
  (21,36,21),
  (5,16,96),
  (2,25,29),
  (7,24,30),
  (1,26,80),
  (21,15,55),
  (26,7,98),
  (7,36,38),
  (27,40,25);
INSERT INTO productSeller (`idPSeller`,`idProduct`,`prodQuantity`)
VALUES
  (21,11,30),
  (25,14,16),
  (2,16,10),
  (21,8,72),
  (2,18,68),
  (9,3,68),
  (9,26,34),
  (23,21,39),
  (25,10,15),
  (27,28,62);
