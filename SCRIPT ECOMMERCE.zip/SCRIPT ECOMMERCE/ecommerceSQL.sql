-- criação de bd para o cenário de E-commerce
-- create database ecommerce;


-- criar tabela cliente OK
create table clients(
		idClient int auto_increment primary key,
        Fname varchar(10),
        Minit char(3),
        Lname varchar(20),
        CPF char(11) not null,
        Address varchar(30),
        constraint unique_cpf_client unique(CPF)
);

-- criar tabela  produto OK
CREATE TABLE product (
    idProduct INT AUTO_INCREMENT PRIMARY KEY,
    Pname VARCHAR(10) NOT NULL,
    classification_kids BOOL DEFAULT FALSE,
    categorie ENUM('Eletrônico', 'Vestimenta', 'Brinquedos', 'Alimentos', 'Móveis') NOT NULL,
    avaliacao FLOAT DEFAULT 0,
    size VARCHAR(10)
);

-- criar tabela pedido OK
create table orders(
		idOrder int auto_increment primary key,
        idOrderClient int,
        orderStatus  enum('Cancelado', 'Confirmado', 'Em Processamento') default 'Em Processamento',
        orderDescription varchar(255),
        sendValue float default 10,
        paymentCash bool default false,
        constraint fk_orders_client foreign key (idOrderClient) references clients(idClient)
);
-- criar tabela estoque OK
create table productStorage(
		idProdStorage int auto_increment primary key,
        storageLocation varchar(255),
        quantity int default 0
);
-- criar tabela fornecedor OK
create table supplier(
		idSupplier int auto_increment primary key,
        socialName varchar(255) not null,
        CNPJ char(15) not null, 
        contact char(11) not null, 
        constraint unique_supplier unique(CNPJ)
);
-- criar tabela vendedor OK
create table seller(
		idSeller int auto_increment primary key,
        socialName varchar(255) not null,
        abstName varchar(255),
        CNPJ char(15), 
        CPF char(11), 
        location varchar(255),
        contact char(11) not null, 
        constraint unique_supplier_cnpj unique(CNPJ),
        constraint unique_supplier_cpf unique(CPF)
);

-- criar tabela vendedor do produto OK
CREATE TABLE productSeller (
    idPSeller INT,
    idProduct INT,
    prodQuantity INT DEFAULT 1,
    PRIMARY KEY (idPSeller , idProduct),
    CONSTRAINT fk_product_seller FOREIGN KEY (idPSeller)
        REFERENCES seller (idSeller),
    CONSTRAINT fk_product_product FOREIGN KEY (idProduct)
        REFERENCES product (idProduct)
);

-- criar tabela de pedido do produto 
create table productOrder(
		idPOproduct int,
        idPOorder int,
        poQuantity int default 1,
		poStatus  enum('Disponível', 'Sem Estoque') default 'Disponível',
        primary key(idPOproduct, idPOorder),
        constraint fk_productorder_seller foreign key (idPOproduct) references product(idProduct),
        constraint fk_productorder_product foreign key (idPOorder) references orders(idOrder)
);

-- criar tabela de localização de armazenamento do produto
create table storageLocation(
		idLproduct int,
        idLstorage int,
        location varchar(255) not null,
        primary key(idLproduct, idLstorage),
        constraint fk_storage_location_product foreign key (idLproduct) references product(idProduct),
        constraint fk_storage_location_storage foreign key (idLstorage) references productStorage(idProdStorage)
);

-- criar tabela de fornecedor do produto
create table productSupplier(
		idPsSupplier int,
        idPsProduct int,
        quantity int not null,
        primary key(idPsSupplier, idPsProduct),
        constraint fk_product_supplier_supplier foreign key (idPsSupplier) references supplier(idSupplier),
        constraint fk_product_supplier_product foreign key (idPsProduct) references product(idProduct)
);

show tables;