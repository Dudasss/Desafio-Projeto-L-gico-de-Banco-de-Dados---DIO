use ecommerce;

-- ordenando os clientes por inicial do nome do meio (Minit)
SELECT 
    *
FROM
    clients
ORDER BY Minit;

SELECT 
    *
FROM
    orders;
    
SELECT 
    *
FROM
    product;
    
SELECT 
    *
FROM
    productorder;
    
SELECT 
    *
FROM
    productseller;
    
SELECT 
    *
FROM
    seller;

-- quais clientes possuem o status de pedido em confirmado? 
SELECT 
    c.idClient, c.Fname, o.orderStatus
FROM
    clients c
        JOIN
    orders o ON c.idClient = o.idOrderClient
WHERE
    orderStatus = 'Confirmado';

-- quantos clientes possuem o status de pedido cancelados? 
SELECT 
    COUNT(*) cancelados
FROM
    clients c
        JOIN
    orders o ON c.idClient = o.idOrderClient
WHERE
    orderStatus = 'Cancelado';
    
 -- quantos pedidos cada cliente fez?   
SELECT 
    c.idClient, c.FName, COUNT(o.idOrder) pedido
FROM
    clients c
        JOIN
    orders o ON c.idClient = o.idOrderClient
GROUP BY 1 , 2
ORDER BY 1;

-- quantos pedidos cancelados cada cliente possui?
SELECT 
    c.idClient, c.FName, o.idOrder, o.orderStatus, COUNT(o.idOrder) pedido
FROM
    clients c
        JOIN
    orders o ON c.idClient = o.idOrderClient
WHERE
    orderStatus = 'Cancelado'
GROUP BY 1 , 2
ORDER BY 1;

-- quantos produtos temos em cada categoria
SELECT COUNT(*) qtd_produtos, p.categorie
FROM productseller ps
JOIN product p
ON ps.idProduct = p.idProduct
GROUP BY 2
ORDER BY 1;

-- quantos produtos cada vendedor tem cadastrado vendedores 
SELECT COUNT(s.idSeller) qtd_prod_cadastrados, s.socialName
FROM productseller ps
JOIN seller s
ON ps.idPSeller = s.idSeller
GROUP BY 2
ORDER BY 1;